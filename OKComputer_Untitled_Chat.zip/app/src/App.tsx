import { Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Services from './pages/Services';
import Gallery from './pages/Gallery';
import Training from './pages/Training';

function App() {
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'auto';
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-[#f5f5f5]">
      <ScrollToTop />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/training" element={<Training />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
