const BOT_TOKEN = '8087011039:AAHk4YVzrwBFn-kaao0IarEB2VjrpICBzBw';
const CHAT_ID = '8087011039';

export interface TelegramData {
  name: string;
  phone: string;
  carClass?: string;
  services?: string[];
  price?: string;
  comment?: string;
  service?: string;
}

export async function sendToTelegram(data: TelegramData): Promise<void> {
  const now = new Date();
  const dateStr = now.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const servicesText = data.services && data.services.length > 0
    ? data.services.join(', ')
    : data.service || '-';

  const message = `
🚗 <b>Новая заявка SMR Detailing</b>

👤 <b>Имя:</b> ${data.name}
📞 <b>Телефон:</b> ${data.phone}
🚘 <b>Класс авто:</b> ${data.carClass || '-'}
🔧 <b>Услуги:</b> ${servicesText}
💰 <b>Ориентировочная стоимость:</b> ${data.price || '-'}
🕐 <b>Дата заявки:</b> ${dateStr}
${data.comment ? `💬 <b>Комментарий:</b> ${data.comment}` : ''}
  `.trim();

  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: message,
      parse_mode: 'HTML',
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to send Telegram message');
  }
}
