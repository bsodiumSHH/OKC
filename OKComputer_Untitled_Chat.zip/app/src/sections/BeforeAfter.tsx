import { useState, useRef, useCallback, useEffect } from 'react';
import { MoveHorizontal } from 'lucide-react';

interface BeforeAfterSliderProps {
  image: string;
  labelBefore?: string;
  labelAfter?: string;
}

function BeforeAfterSlider({
  image,
  labelBefore = 'ДО',
  labelAfter = 'ПОСЛЕ',
}: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMove = useCallback(
    (clientX: number) => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const x = clientX - rect.left;
      const percent = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setSliderPosition(percent);
    },
    []
  );

  const handleMouseDown = useCallback(() => {
    isDragging.current = true;
  }, []);

  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      if (isDragging.current) handleMove(e.clientX);
    },
    [handleMove]
  );

  const handleMouseUp = useCallback(() => {
    isDragging.current = false;
  }, []);

  const handleTouchMove = useCallback(
    (e: TouchEvent) => {
      if (isDragging.current && e.touches[0]) {
        handleMove(e.touches[0].clientX);
      }
    },
    [handleMove]
  );

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp, handleTouchMove]);

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[16/9] overflow-hidden rounded-xl cursor-col-resize select-none"
      onMouseDown={handleMouseDown}
      onTouchStart={handleMouseDown}
    >
      {/* After image (full) */}
      <img
        src={image}
        alt="After"
        className="absolute inset-0 w-full h-full object-cover"
        draggable={false}
      />

      {/* Before overlay (clipped) */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        <img
          src={image}
          alt="Before"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'brightness(0.4) saturate(0.3)' }}
          draggable={false}
        />
      </div>

      {/* Labels */}
      <span className="absolute top-4 left-4 bg-[rgba(0,0,0,0.6)] text-[#888] text-xs px-3 py-1 rounded-full font-medium z-10">
        {labelBefore}
      </span>
      <span className="absolute top-4 right-4 bg-[rgba(255,26,26,0.8)] text-white text-xs px-3 py-1 rounded-full font-medium z-10">
        {labelAfter}
      </span>

      {/* Slider Line */}
      <div
        className="absolute top-0 bottom-0 w-[2px] bg-[#ff1a1a] z-10"
        style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
      >
        {/* Handle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-[#ff1a1a] flex items-center justify-center shadow-lg shadow-[rgba(255,26,26,0.4)]">
          <MoveHorizontal size={20} className="text-white" />
        </div>
      </div>
    </div>
  );
}

export default function BeforeAfter() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const items = section.querySelectorAll('.ba-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    items.forEach((item, i) => {
      const el = item as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.15}s, transform 0.6s ease ${i * 0.15}s`;
      observer.observe(item);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6 bg-[#0a0a0a]" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Результаты</p>
        <h2 className="section-title text-[#f5f5f5] mb-12">
          Превращение в деталях
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="ba-item">
            <BeforeAfterSlider
              image="/images/before-after-1.jpg"
              labelBefore="ДО МОЙКИ"
              labelAfter="ПОСЛЕ"
            />
            <p className="text-sm text-[#888] mt-3">Детейлинг-мойка — удаление реагентов и битума</p>
          </div>
          <div className="ba-item">
            <BeforeAfterSlider
              image="/images/before-after-2.jpg"
              labelBefore="ДО ПОЛИРОВКИ"
              labelAfter="ПОСЛЕ"
            />
            <p className="text-sm text-[#888] mt-3">Восстановительная полировка — зеркальный блеск</p>
          </div>
        </div>
      </div>
    </section>
  );
}
