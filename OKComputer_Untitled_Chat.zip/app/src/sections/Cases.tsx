import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import { CASES } from '@/lib/constants';

export default function Cases() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const cards = section.querySelectorAll('.case-card');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
      observer.observe(card);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Кейсы</p>
        <h2 className="section-title text-[#f5f5f5] mb-12">
          Реальные работы, реальные результаты
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CASES.map((c) => (
            <div key={c.car} className="case-card glass-card overflow-hidden group">
              {/* Image */}
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={c.image}
                  alt={c.car}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-[#111]/40 to-transparent" />
                {/* Overlay text */}
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <p className="font-mono text-xs text-[#ff1a1a] mb-1">{c.price}</p>
                  <h3 className="text-lg font-semibold text-[#f5f5f5] mb-1">{c.car}</h3>
                  <p className="text-xs text-[#888]">{c.service}</p>
                </div>
              </div>

              {/* Details */}
              <div className="p-5 space-y-3">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-[#555] mb-1">Проблема</p>
                  <p className="text-sm text-[#888]">{c.problem}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-[#555] mb-1">Результат</p>
                  <p className="text-sm text-[#f5f5f5]">{c.result}</p>
                </div>
                <div className="pt-2">
                  <button className="inline-flex items-center gap-1 text-xs text-[#ff1a1a] hover:gap-2 transition-all">
                    Подробнее
                    <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
