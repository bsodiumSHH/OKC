import { useEffect, useRef } from 'react';
import { MapPin, Phone, Clock, MessageCircle, ExternalLink } from 'lucide-react';
import { COMPANY } from '@/lib/constants';
import LeadForm from '@/components/LeadForm';

export default function Contacts() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const items = section.querySelectorAll('.contact-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    items.forEach((item, i) => {
      const el = item as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
      observer.observe(item);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="contacts"
      className="py-[120px] px-6"
      style={{
        background: 'radial-gradient(ellipse at center, rgba(26,0,0,0.5) 0%, #050505 70%)',
      }}
      ref={sectionRef}
    >
      <div className="max-w-[1280px] mx-auto">
        <div className="text-center mb-12">
          <h2 className="section-title text-[#f5f5f5] mb-4">
            Готовы к идеальному результату?
          </h2>
          <p className="text-[#888] max-w-[500px] mx-auto">
            Запишитесь на консультацию или приезжайте по адресу
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact Info */}
          <div className="contact-item space-y-6">
            {/* Info Cards */}
            <div className="space-y-4">
              <div className="glass-card p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[rgba(255,26,26,0.1)] flex items-center justify-center flex-shrink-0">
                  <MapPin size={18} className="text-[#ff1a1a]" />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-[#555] mb-0.5">Адрес</p>
                  <p className="text-sm text-[#f5f5f5]">{COMPANY.address}</p>
                </div>
              </div>

              <a
                href={`tel:${COMPANY.phoneRaw}`}
                className="glass-card p-5 flex items-center gap-4 block hover:border-[rgba(255,255,255,0.15)] transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-[rgba(255,26,26,0.1)] flex items-center justify-center flex-shrink-0">
                  <Phone size={18} className="text-[#ff1a1a]" />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-[#555] mb-0.5">Телефон</p>
                  <p className="text-sm text-[#f5f5f5] font-mono">{COMPANY.phone}</p>
                </div>
              </a>

              <div className="glass-card p-5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[rgba(255,26,26,0.1)] flex items-center justify-center flex-shrink-0">
                  <Clock size={18} className="text-[#ff1a1a]" />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-[#555] mb-0.5">Режим работы</p>
                  <p className="text-sm text-[#f5f5f5]">{COMPANY.hours}</p>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-3">
              <a
                href={COMPANY.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 glass-card px-4 py-3 text-sm text-[#888] hover:text-[#f5f5f5] transition-colors"
              >
                <MessageCircle size={16} />
                Telegram
              </a>
              <a
                href={COMPANY.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 glass-card px-4 py-3 text-sm text-[#888] hover:text-[#f5f5f5] transition-colors"
              >
                <MessageCircle size={16} />
                WhatsApp
              </a>
              <a
                href={COMPANY.yandexMap}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 glass-card px-4 py-3 text-sm text-[#888] hover:text-[#f5f5f5] transition-colors"
              >
                <ExternalLink size={16} />
                Карта
              </a>
            </div>

            {/* Map */}
            <div className="rounded-xl overflow-hidden border border-[rgba(255,255,255,0.08)]">
              <iframe
                src="https://yandex.ru/map-widget/v1/?ll=44.465313%2C48.694533&z=16&pt=44.465313%2C48.694533"
                width="100%"
                height="300"
                className="border-0 grayscale opacity-70"
                title="SMR Detailing на карте"
                loading="lazy"
              />
            </div>
          </div>

          {/* Form */}
          <div className="contact-item">
            <div className="glass-card p-6 sm:p-8">
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-6">
                Оставить заявку
              </h3>
              <LeadForm />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
