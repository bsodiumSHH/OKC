import { useEffect, useRef } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { FAQ_ITEMS } from '@/lib/constants';

export default function FAQ() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const el = section.querySelector('.faq-wrapper') as HTMLElement;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.05 }
    );
    el.style.opacity = '0';
    el.style.transform = 'translateY(40px)';
    el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6" ref={sectionRef}>
      <div className="max-w-[800px] mx-auto faq-wrapper">
        <p className="section-label mb-4 text-center">FAQ</p>
        <h2 className="section-title text-[#f5f5f5] mb-12 text-center">
          Ответы на вопросы
        </h2>

        <Accordion type="single" collapsible className="space-y-3">
          {FAQ_ITEMS.map((item, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="glass-card border-none px-5 data-[state=open]:bg-[rgba(255,255,255,0.05)]"
            >
              <AccordionTrigger className="text-left text-sm font-medium text-[#f5f5f5] hover:no-underline py-5">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-[#888] leading-relaxed pb-5">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
