import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Phone } from 'lucide-react';
import HeroCanvas from '@/components/HeroCanvas';

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const canvas = sectionRef.current?.querySelector('canvas');
    if (canvas) {
      const handleScroll = () => {
        const scrollY = window.scrollY;
        const vh = window.innerHeight;
        const progress = Math.min(scrollY / vh, 1);
        canvas.style.opacity = String(1 - progress);
      };
      window.addEventListener('scroll', handleScroll, { passive: true });
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, []);

  const scrollToAI = () => {
    const el = document.getElementById('ai-configurator');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section ref={sectionRef} className="relative min-h-[100dvh] flex items-center overflow-hidden">
      {/* Three.js Background */}
      <HeroCanvas />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/60 via-transparent to-[#050505] z-[1]" />

      {/* Content */}
      <div className="relative z-[2] w-full max-w-[1280px] mx-auto px-6 pt-[72px]">
        <div className="max-w-[800px]">
          {/* Label */}
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#888] mb-6">
            Детейлинг-премиум • Волгоград
          </p>

          {/* H1 */}
          <h1 className="font-display text-[clamp(32px,6vw,68px)] uppercase leading-[1] tracking-[0.02em] text-[#f5f5f5] mb-6">
            Идеальный автомобиль начинается с деталей
          </h1>

          {/* Subtitle */}
          <p className="text-lg text-[#888] max-w-[520px] leading-relaxed mb-10">
            SMR Detailing — студия премиального ухода за автомобилем. Полировка, керамика, химчистка, бронирование. Рейтинг 5.0, 55+ отзывов.
          </p>

          {/* CTA Group */}
          <div className="flex flex-wrap gap-4 mb-16">
            <Link
              to="/#contacts"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('contacts')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-primary"
            >
              <Phone size={16} />
              Записаться на услугу
            </Link>
            <button onClick={scrollToAI} className="btn-secondary">
              <Sparkles size={16} />
              AI-расчёт стоимости
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-8 sm:gap-12 pb-12">
          {[
            { value: '5.0', label: 'Рейтинг' },
            { value: '55+', label: 'Отзывов' },
            { value: '81', label: 'Оценка' },
            { value: '2019', label: 'Год основания' },
          ].map((stat) => (
            <div key={stat.label}>
              <p className="font-mono text-[28px] sm:text-[32px] font-bold text-[#f5f5f5]">
                {stat.value}
              </p>
              <p className="text-[11px] uppercase tracking-[0.15em] text-[#555] mt-1">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
