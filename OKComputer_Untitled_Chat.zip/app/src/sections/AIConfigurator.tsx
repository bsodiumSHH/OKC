import { useState, useRef, useEffect, useCallback } from 'react';
import { Upload, Check, ChevronLeft, ChevronRight, AlertTriangle, Sparkles } from 'lucide-react';
import CountUp from 'react-countup';
import { CAR_CLASSES, SERVICES } from '@/lib/constants';
import LeadForm from '@/components/LeadForm';

type Step = 1 | 2 | 3 | 4;

const AI_STEPS = [
  { num: 1, label: 'Авто' },
  { num: 2, label: 'Фото' },
  { num: 3, label: 'Услуги' },
  { num: 4, label: 'Результат' },
];

const CAR_SVG = (
  <svg viewBox="0 0 120 60" className="w-24 h-12 mx-auto mb-4" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M10 40 Q10 35 15 32 L25 30 L35 18 Q38 15 42 15 H75 Q80 15 82 18 L90 30 L100 32 Q105 35 105 40 V45 Q105 48 102 48 H95 Q92 48 92 45 V42 H28 V45 Q28 48 25 48 H18 Q15 48 15 45 V42 Q10 42 10 40Z" />
    <circle cx="30" cy="48" r="6" />
    <circle cx="88" cy="48" r="6" />
    <path d="M38 20 H72 L80 30 H32Z" opacity="0.3" />
  </svg>
);

const CROSSOVER_SVG = (
  <svg viewBox="0 0 120 60" className="w-24 h-12 mx-auto mb-4" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M8 38 Q8 32 14 29 L28 26 L38 14 Q42 10 48 10 H78 Q84 10 86 14 L94 26 L104 29 Q110 32 110 38 V44 Q110 48 106 48 H98 Q94 48 94 44 V42 H26 V44 Q26 48 22 48 H14 Q10 48 10 44 V40 Q8 40 8 38Z" />
    <circle cx="28" cy="50" r="7" />
    <circle cx="92" cy="50" r="7" />
    <path d="M42 16 H76 L84 26 H36Z" opacity="0.3" />
  </svg>
);

const SUV_SVG = (
  <svg viewBox="0 0 120 60" className="w-24 h-12 mx-auto mb-4" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M5 36 Q5 28 12 25 L28 22 L40 10 Q45 6 52 6 H82 Q88 6 90 10 L98 22 L108 25 Q114 28 114 36 V44 Q114 48 110 48 H102 Q98 48 98 44 V42 H22 V44 Q22 48 18 48 H10 Q6 48 6 44 V38 Q5 38 5 36Z" />
    <circle cx="26" cy="50" r="8" />
    <circle cx="94" cy="50" r="8" />
    <path d="M44 12 H78 L86 22 H38Z" opacity="0.3" />
    <rect x="92" y="14" width="10" height="8" rx="2" opacity="0.3" />
  </svg>
);

const CAR_SVGS = [CAR_SVG, CROSSOVER_SVG, SUV_SVG];

const SCAN_STATUSES = [
  'Подключение к AI-модулю…',
  'Определение геометрии кузова…',
  'Анализ изображения…',
  'Подготовка предварительной оценки…',
  'Готово ✓',
];

export default function AIConfigurator() {
  const [step, setStep] = useState<Step>(1);
  const [carClass, setCarClass] = useState<string>('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanComplete, setScanComplete] = useState(false);
  const [selectedServices, setSelectedServices] = useState<Set<string>>(new Set());
  const [showForm, setShowForm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    const el = section.querySelector('.config-wrapper') as HTMLElement;
    if (el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
      observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  const handleFileUpload = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setUploadedImage(e.target?.result as string);
      // Start scan animation
      let progress = 0;
      const interval = setInterval(() => {
        progress += 20;
        setScanProgress(progress);
        if (progress >= 100) {
          clearInterval(interval);
          setTimeout(() => setScanComplete(true), 300);
        }
      }, 800);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        handleFileUpload(file);
      }
    },
    [handleFileUpload]
  );

  const toggleService = (id: string) => {
    setSelectedServices((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectedCarClass = CAR_CLASSES.find((c) => c.id === carClass);
  const factor = selectedCarClass?.factor || 1;
  const selectedServicesList = SERVICES.filter((s) => selectedServices.has(s.id));
  const totalBase = selectedServicesList.reduce((sum, s) => sum + s.basePrice, 0);
  const total = Math.round(totalBase * factor);

  const canProceed =
    (step === 1 && carClass) ||
    (step === 2 && scanComplete) ||
    (step === 3 && selectedServices.size > 0) ||
    step === 4;

  return (
    <section id="ai-configurator" className="py-[120px] px-6 bg-[#050505]" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto config-wrapper">
        {/* Header */}
        <div className="text-center mb-12">
          <p className="section-label mb-4 flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#ff1a1a] animate-pulse" />
            AI-предварительная оценка
          </p>
          <h2 className="section-title text-[#f5f5f5] mb-4">
            Рассчитайте стоимость за 60 секунд
          </h2>
          <p className="text-[#888] max-w-[600px] mx-auto">
            Выберите класс автомобиля, загрузите фото и укажите нужные услуги. Система рассчитает ориентировочную стоимость.
          </p>
        </div>

        {/* Configurator Container */}
        <div className="max-w-[900px] mx-auto bg-[#0a0a0a] border border-[rgba(255,255,255,0.08)] rounded-2xl p-6 sm:p-10">
          {/* Progress */}
          <div className="flex items-center justify-between mb-10">
            {AI_STEPS.map((s, i) => (
              <div key={s.num} className="flex items-center flex-1">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all duration-300 ${
                      step >= s.num
                        ? 'bg-[#ff1a1a] text-white'
                        : 'bg-[#222] text-[#555]'
                    }`}
                  >
                    {step > s.num ? <Check size={14} /> : s.num}
                  </div>
                  <span
                    className={`text-[10px] uppercase tracking-wider mt-2 hidden sm:block ${
                      step >= s.num ? 'text-[#f5f5f5]' : 'text-[#555]'
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
                {i < AI_STEPS.length - 1 && (
                  <div
                    className={`flex-1 h-[2px] mx-2 transition-all duration-500 ${
                      step > s.num ? 'bg-[#ff1a1a]' : 'bg-[#222]'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Car Class */}
          {step === 1 && (
            <div>
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-6 text-center">
                Выберите класс автомобиля
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {CAR_CLASSES.map((cls, i) => (
                  <button
                    key={cls.id}
                    onClick={() => setCarClass(cls.id)}
                    className={`relative p-6 rounded-xl border transition-all duration-300 text-center ${
                      carClass === cls.id
                        ? 'border-[#ff1a1a] bg-[rgba(255,26,26,0.08)]'
                        : 'border-[rgba(255,255,255,0.1)] bg-[#111] hover:border-[rgba(255,255,255,0.2)]'
                    }`}
                  >
                    {carClass === cls.id && (
                      <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#ff1a1a] flex items-center justify-center">
                        <Check size={12} className="text-white" />
                      </div>
                    )}
                    <div className={carClass === cls.id ? 'text-[#ff1a1a]' : 'text-[#555]'}>
                      {CAR_SVGS[i]}
                    </div>
                    <p className="text-sm font-semibold text-[#f5f5f5] mb-1">{cls.shortName}</p>
                    <p className="text-xs text-[#888]">{cls.name}</p>
                    <p className="font-mono text-xs text-[#ff1a1a] mt-2">{cls.coeff}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Photo Upload */}
          {step === 2 && (
            <div>
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-6 text-center">
                Загрузите фото автомобиля
              </h3>
              {!uploadedImage ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={(e) => e.preventDefault()}
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-[#333] rounded-2xl p-12 text-center cursor-pointer hover:border-[#ff1a1a] transition-colors"
                >
                  <Upload size={48} className="mx-auto text-[#555] mb-4" />
                  <p className="text-[#888] mb-2">Перетащите фото сюда или нажмите для выбора</p>
                  <p className="text-xs text-[#555]">JPG, PNG, до 10MB</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                  />
                </div>
              ) : (
                <div className="relative rounded-xl overflow-hidden">
                  <img src={uploadedImage} alt="Uploaded car" className="w-full max-h-[400px] object-cover" />
                  {!scanComplete && (
                    <>
                      {/* Laser scan line */}
                      <div
                        className="absolute left-0 right-0 h-[2px] bg-[#ff1a1a] z-10"
                        style={{
                          top: `${scanProgress}%`,
                          boxShadow: '0 0 20px 4px rgba(255,26,26,0.5), 0 0 60px 8px rgba(255,26,26,0.2)',
                          transition: 'top 0.8s ease',
                        }}
                      />
                      {/* Scan overlay */}
                      <div className="absolute inset-0 bg-[rgba(0,0,0,0.4)]" />
                      {/* Status */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
                        <div className="w-16 h-16 rounded-full border-2 border-[#ff1a1a] border-t-transparent animate-spin mb-4" />
                        <p className="text-sm text-[#f5f5f5] font-medium">
                          {SCAN_STATUSES[Math.floor(scanProgress / 20)] || SCAN_STATUSES[0]}
                        </p>
                        <div className="w-48 h-1 bg-[#222] rounded-full mt-3 overflow-hidden">
                          <div
                            className="h-full bg-[#ff1a1a] rounded-full transition-all duration-300"
                            style={{ width: `${scanProgress}%` }}
                          />
                        </div>
                      </div>
                    </>
                  )}
                  {scanComplete && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-[rgba(0,0,0,0.6)]">
                      <div className="w-12 h-12 rounded-full bg-[rgba(34,197,94,0.2)] flex items-center justify-center mb-3">
                        <Check size={24} className="text-[#22c55e]" />
                      </div>
                      <p className="text-[#22c55e] font-medium">Анализ завершён</p>
                    </div>
                  )}
                </div>
              )}

              {/* Disclaimer */}
              <div className="flex items-start gap-2 mt-4 p-3 rounded-lg bg-[rgba(255,255,255,0.02)]">
                <AlertTriangle size={14} className="text-[#555] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[#555]">
                  Это демонстрация предварительной оценки. Окончательная стоимость определяется после осмотра специалистом.
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Services */}
          {step === 3 && (
            <div>
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-6 text-center">
                Выберите нужные услуги
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SERVICES.map((service) => {
                  const isSelected = selectedServices.has(service.id);
                  const isOnRequest = service.basePrice === 0;
                  return (
                    <button
                      key={service.id}
                      onClick={() => toggleService(service.id)}
                      className={`flex items-center gap-4 p-4 rounded-xl border text-left transition-all duration-200 ${
                        isSelected
                          ? 'border-l-[3px] border-l-[#ff1a1a] border-[rgba(255,255,255,0.15)] bg-[rgba(255,26,26,0.05)]'
                          : 'border-[rgba(255,255,255,0.08)] bg-[#111] hover:border-[rgba(255,255,255,0.15)]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 transition-colors ${
                          isSelected ? 'bg-[#ff1a1a] border-[#ff1a1a]' : 'border-[#555]'
                        }`}
                      >
                        {isSelected && <Check size={12} className="text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#f5f5f5]">{service.name}</p>
                        <p className="font-mono text-xs text-[#ff1a1a] mt-0.5">
                          {isOnRequest ? 'по запросу' : `от ${service.basePrice.toLocaleString('ru-RU')} ₽`}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 4: Result */}
          {step === 4 && (
            <div>
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-6 text-center">
                Предварительная оценка
              </h3>

              {!showForm ? (
                <>
                  {/* Summary */}
                  <div className="bg-[#111] rounded-xl p-6 mb-6">
                    <div className="flex items-center justify-between mb-4 pb-4 border-b border-[rgba(255,255,255,0.06)]">
                      <span className="text-sm text-[#888]">Класс автомобиля</span>
                      <span className="text-sm text-[#f5f5f5]">
                        {selectedCarClass?.name} ({selectedCarClass?.coeff})
                      </span>
                    </div>

                    {selectedServicesList.map((s) => (
                      <div key={s.id} className="flex items-center justify-between py-2">
                        <span className="text-sm text-[#888]">{s.name}</span>
                        <span className="font-mono text-sm text-[#f5f5f5]">
                          {s.basePrice === 0 ? 'по запросу' : `${(s.basePrice * factor).toLocaleString('ru-RU')} ₽`}
                        </span>
                      </div>
                    ))}

                    <div className="mt-4 pt-4 border-t border-[rgba(255,255,255,0.1)]">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-[#888]">Итого</span>
                        <span className="font-mono text-[clamp(24px,4vw,40px)] font-bold text-[#f5f5f5]">
                          {total > 0 ? (
                            <CountUp end={total} duration={1.5} separator=" " suffix=" ₽" />
                          ) : (
                            'по запросу'
                          )}
                        </span>
                      </div>
                      <p className="text-xs text-[#555] mt-1 text-right">
                        Базовая цена × коэффициент класса
                      </p>
                    </div>
                  </div>

                  {/* Warning */}
                  <div className="flex items-start gap-2 mb-6 p-3 rounded-lg bg-[rgba(255,26,26,0.05)] border border-[rgba(255,26,26,0.1)]">
                    <AlertTriangle size={14} className="text-[#ff1a1a] mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-[#ff1a1a]">
                      * Окончательная стоимость определяется после осмотра специалистом
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row gap-4">
                    <button onClick={() => setShowForm(true)} className="btn-primary flex-1">
                      <Sparkles size={16} />
                      Оставить заявку
                    </button>
                    <button onClick={() => setStep(1)} className="btn-secondary">
                      <ChevronLeft size={16} />
                      Изменить выбор
                    </button>
                  </div>
                </>
              ) : (
                <div className="bg-[#111] rounded-xl p-6">
                  <button
                    onClick={() => setShowForm(false)}
                    className="text-sm text-[#888] hover:text-[#f5f5f5] mb-4 flex items-center gap-1"
                  >
                    <ChevronLeft size={14} />
                    Назад к результату
                  </button>
                  <LeadForm
                    prefilledCarClass={selectedCarClass?.name}
                    prefilledServices={selectedServicesList.map((s) => s.name)}
                    prefilledPrice={total > 0 ? `${total.toLocaleString('ru-RU')} ₽` : undefined}
                  />
                </div>
              )}
            </div>
          )}

          {/* Navigation */}
          {step < 4 && (
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-[rgba(255,255,255,0.06)]">
              <button
                onClick={() => setStep((s) => Math.max(1, s - 1) as Step)}
                disabled={step === 1}
                className="flex items-center gap-1 text-sm text-[#888] hover:text-[#f5f5f5] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft size={16} />
                Назад
              </button>
              <span className="text-xs text-[#555] font-mono">
                {step} / 4
              </span>
              <button
                onClick={() => setStep((s) => Math.min(4, s + 1) as Step)}
                disabled={!canProceed}
                className="btn-primary text-xs py-3 px-6 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                Далее
                <ChevronRight size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
