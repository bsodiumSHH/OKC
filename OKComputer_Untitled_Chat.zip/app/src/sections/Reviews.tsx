import { useEffect, useRef } from 'react';
import { Star, ExternalLink } from 'lucide-react';
import { COMPANY, REVIEWS } from '@/lib/constants';

export default function Reviews() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const cards = section.querySelectorAll('.review-card');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.08}s, transform 0.6s ease ${i * 0.08}s`;
      observer.observe(card);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <section id="reviews" className="py-[120px] px-6 bg-[#0a0a0a]" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Отзывы</p>
        <h2 className="section-title text-[#f5f5f5] mb-8">
          Что говорят клиенты
        </h2>

        {/* Rating */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-12 pb-8 border-b border-[rgba(255,255,255,0.06)]">
          <span className="font-mono text-[56px] sm:text-[72px] font-bold text-[#f5f5f5] leading-none">
            {COMPANY.rating.toFixed(1)}
          </span>
          <div>
            <div className="flex items-center gap-1 mb-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star
                  key={i}
                  size={20}
                  className="text-[#ff1a1a]"
                  fill="#ff1a1a"
                />
              ))}
            </div>
            <p className="text-sm text-[#888]">
              {COMPANY.scores} оценка • {COMPANY.reviews} отзывов
            </p>
          </div>
        </div>

        {/* Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {REVIEWS.map((review) => (
            <div key={review.name} className="review-card glass-card p-6">
              {/* Quote */}
              <p className="text-[40px] leading-none text-[#ff1a1a] opacity-30 mb-2">&ldquo;</p>
              <p className="text-sm text-[#ccc] leading-relaxed mb-6 line-clamp-6">
                {review.text}
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-[rgba(255,255,255,0.06)]">
                <div className="w-10 h-10 rounded-full bg-[#222] flex items-center justify-center text-sm font-semibold text-[#888]">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-[#f5f5f5]">{review.name}</p>
                  <p className="text-xs text-[#555]">{review.level} • {review.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Link to Yandex */}
        <div className="mt-10 text-center">
          <a
            href={COMPANY.yandexMap}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm text-[#888] hover:text-[#ff1a1a] transition-colors"
          >
            Все отзывы на Яндекс.Картах
            <ExternalLink size={14} />
          </a>
        </div>
      </div>
    </section>
  );
}
