import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Droplets, Sparkles, SprayCan, Shield, Layers, Cog, ArrowRight } from 'lucide-react';
import { SERVICES } from '@/lib/constants';

const DISPLAY_SERVICES = SERVICES.slice(0, 6);

const ICON_MAP: Record<string, React.ReactNode> = {
  wash: <Droplets size={28} />,
  polish: <Sparkles size={28} />,
  interior: <SprayCan size={28} />,
  ceramic: <Shield size={28} />,
  ppf: <Layers size={28} />,
  engine: <Cog size={28} />,
};

export default function PopularServices() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll('.service-card');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );

    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.08}s, transform 0.6s ease ${i * 0.08}s`;
      observer.observe(card);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6 bg-[#0a0a0a]" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Услуги</p>
        <h2 className="section-title text-[#f5f5f5] mb-16">
          Полный спектр детейлинга
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DISPLAY_SERVICES.map((service) => (
            <div
              key={service.id}
              className="service-card glass-card overflow-hidden group cursor-pointer"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#111] to-transparent" />
                <div className="absolute top-4 left-4 text-[#ff1a1a]">{ICON_MAP[service.id]}</div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-[#f5f5f5] mb-2">{service.name}</h3>
                <p className="text-sm text-[#888] mb-4 line-clamp-2">{service.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[#ff1a1a] text-sm">
                    от {service.basePrice.toLocaleString('ru-RU')} ₽
                  </span>
                  <span className="text-[#555] group-hover:text-[#ff1a1a] transition-colors">
                    <ArrowRight size={18} />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Link
            to="/services"
            className="btn-secondary inline-flex"
          >
            Все услуги
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
