import { useEffect, useRef } from 'react';
import { Diamond, Shield, Clock, GraduationCap } from 'lucide-react';
import { ADVANTAGES } from '@/lib/constants';

const ICON_MAP: Record<string, React.ReactNode> = {
  Diamond: <Diamond size={28} className="text-[#ff1a1a]" />,
  Shield: <Shield size={28} className="text-[#ff1a1a]" />,
  Clock: <Clock size={28} className="text-[#ff1a1a]" />,
  GraduationCap: <GraduationCap size={28} className="text-[#ff1a1a]" />,
};

export default function Advantages() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll('.advantage-card');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );

    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
      observer.observe(card);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Почему SMR</p>
        <h2 className="section-title text-[#f5f5f5] mb-16 max-w-[700px]">
          Стандарты, которые не пересматриваются
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {ADVANTAGES.map((adv) => (
            <div
              key={adv.title}
              className="advantage-card glass-card p-8 transition-all duration-400"
            >
              <div className="mb-5">{ICON_MAP[adv.icon]}</div>
              <h3 className="text-lg font-semibold text-[#f5f5f5] mb-3">{adv.title}</h3>
              <p className="text-sm text-[#888] leading-relaxed">{adv.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
