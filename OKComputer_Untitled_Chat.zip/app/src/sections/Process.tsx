import { useEffect, useRef } from 'react';
import { Phone, Search, Wrench, CheckCircle } from 'lucide-react';
import { PROCESS_STEPS } from '@/lib/constants';

const ICON_MAP: Record<string, React.ReactNode> = {
  Phone: <Phone size={24} />,
  Search: <Search size={24} />,
  Wrench: <Wrench size={24} />,
  CheckCircle: <CheckCircle size={24} />,
};

export default function Process() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll('.process-step');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );

    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.15}s, transform 0.6s ease ${i * 0.15}s`;
      observer.observe(card);
    });

    // Progress bar animation
    const progressBar = progressRef.current;
    if (progressBar) {
      const scrollHandler = () => {
        const rect = section.getBoundingClientRect();
        const vh = window.innerHeight;
        const progress = Math.max(0, Math.min(1, 1 - rect.top / (vh * 0.5)));
        progressBar.style.width = `${progress * 100}%`;
      };
      window.addEventListener('scroll', scrollHandler, { passive: true });
      return () => {
        observer.disconnect();
        window.removeEventListener('scroll', scrollHandler);
      };
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-[120px] px-6" ref={sectionRef}>
      <div className="max-w-[1280px] mx-auto">
        <p className="section-label mb-4">Процесс</p>
        <h2 className="section-title text-[#f5f5f5] mb-16">
          От записи до идеального результата
        </h2>

        {/* Timeline */}
        <div className="relative">
          {/* Line */}
          <div className="hidden lg:block absolute top-[40px] left-0 right-0 h-[2px] bg-[rgba(255,255,255,0.08)]">
            <div
              ref={progressRef}
              className="h-full bg-gradient-to-r from-[#ff1a1a] to-[#cc0000] transition-all duration-100"
              style={{ width: '0%' }}
            />
          </div>

          {/* Steps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {PROCESS_STEPS.map((step) => (
              <div key={step.num} className="process-step relative">
                {/* Circle */}
                <div className="relative z-10 w-20 h-20 rounded-full bg-[#111] border-2 border-[rgba(255,255,255,0.1)] flex items-center justify-center text-[#ff1a1a] mb-6 mx-auto lg:mx-0">
                  {ICON_MAP[step.icon]}
                  <span className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-[#ff1a1a] text-white text-[10px] font-bold flex items-center justify-center">
                    {step.num}
                  </span>
                </div>

                <h3 className="text-lg font-semibold text-[#f5f5f5] mb-2 text-center lg:text-left">
                  {step.title}
                </h3>
                <p className="text-sm text-[#888] text-center lg:text-left leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
