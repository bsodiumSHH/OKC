import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, X, ChevronLeft, ChevronRight } from 'lucide-react';

const GALLERY_ITEMS = [
  { src: '/images/service-wash.jpg', category: 'Мойка', title: 'Детейлинг-мойка' },
  { src: '/images/service-polish.jpg', category: 'Полировка', title: 'Восстановительная полировка' },
  { src: '/images/service-interior.jpg', category: 'Химчистка', title: 'Химчистка салона' },
  { src: '/images/service-ceramic.jpg', category: 'Керамика', title: 'Керамическое покрытие' },
  { src: '/images/service-ppf.jpg', category: 'Бронирование', title: 'Антигравийная плёнка' },
  { src: '/images/service-engine.jpg', category: 'Мойка', title: 'Мойка двигателя' },
  { src: '/images/case-porsche.jpg', category: 'Полировка', title: 'Porsche Cayenne' },
  { src: '/images/case-bmw.jpg', category: 'Химчистка', title: 'BMW X5' },
  { src: '/images/case-mercedes.jpg', category: 'Керамика', title: 'Mercedes S-Class' },
  { src: '/images/showroom.jpg', category: 'Студия', title: 'Наша студия' },
  { src: '/images/before-after-1.jpg', category: 'Мойка', title: 'До/После мойки' },
  { src: '/images/before-after-2.jpg', category: 'Полировка', title: 'До/После полировки' },
];

const FILTERS = ['Все', 'Мойка', 'Полировка', 'Химчистка', 'Керамика', 'Бронирование', 'Студия'];

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState('Все');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  const filteredItems =
    activeFilter === 'Все'
      ? GALLERY_ITEMS
      : GALLERY_ITEMS.filter((item) => item.category === activeFilter);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const items = section.querySelectorAll('.gallery-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.05 }
    );
    items.forEach((item, i) => {
      const el = item as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      el.style.transition = `opacity 0.5s ease ${i * 0.05}s, transform 0.5s ease ${i * 0.05}s`;
      observer.observe(item);
    });
    return () => observer.disconnect();
  }, [activeFilter]);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);
  const prevImage = () =>
    setLightboxIndex((prev) => (prev !== null ? (prev - 1 + filteredItems.length) % filteredItems.length : null));
  const nextImage = () =>
    setLightboxIndex((prev) => (prev !== null ? (prev + 1) % filteredItems.length : null));

  return (
    <div className="pt-[72px]" ref={sectionRef}>
      {/* Hero */}
      <section className="py-20 px-6">
        <div className="max-w-[1280px] mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-[#888] hover:text-[#ff1a1a] transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            На главную
          </Link>
          <p className="section-label mb-4">Галерея</p>
          <h1 className="font-display text-[clamp(32px,5vw,56px)] uppercase leading-[1] tracking-[0.02em] text-[#f5f5f5] mb-8">
            Наши работы
          </h1>

          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider transition-all duration-300 ${
                  activeFilter === filter
                    ? 'bg-[#ff1a1a] text-white'
                    : 'bg-[#111] text-[#888] border border-[rgba(255,255,255,0.1)] hover:border-[rgba(255,255,255,0.2)]'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="pb-[120px] px-6">
        <div className="max-w-[1280px] mx-auto">
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
            {filteredItems.map((item, index) => (
              <div
                key={`${item.src}-${activeFilter}`}
                className="gallery-item break-inside-avoid relative group cursor-pointer overflow-hidden rounded-xl"
                onClick={() => openLightbox(index)}
              >
                <img
                  src={item.src}
                  alt={item.title}
                  className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[rgba(0,0,0,0.8)] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-[#ff1a1a] mb-1">
                      {item.category}
                    </p>
                    <p className="text-sm font-medium text-white">{item.title}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-[100] bg-[rgba(0,0,0,0.95)] flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 text-[#888] hover:text-white transition-colors z-10"
          >
            <X size={28} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              prevImage();
            }}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-[#888] hover:text-white transition-colors z-10"
          >
            <ChevronLeft size={36} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              nextImage();
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-[#888] hover:text-white transition-colors z-10"
          >
            <ChevronRight size={36} />
          </button>

          <div className="max-w-[90vw] max-h-[85vh]" onClick={(e) => e.stopPropagation()}>
            <img
              src={filteredItems[lightboxIndex].src}
              alt={filteredItems[lightboxIndex].title}
              className="max-w-full max-h-[85vh] object-contain rounded-lg"
            />
            <div className="text-center mt-4">
              <p className="text-sm text-[#888]">
                {lightboxIndex + 1} / {filteredItems.length} — {filteredItems[lightboxIndex].title}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
