import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { COURSE_MODULES } from '@/lib/constants';

export default function Training() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const items = section.querySelectorAll('.training-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.1 }
    );
    items.forEach((item, i) => {
      const el = item as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
      observer.observe(item);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div className="pt-[72px]" ref={sectionRef}>
      {/* Hero */}
      <section className="py-20 px-6">
        <div className="max-w-[1280px] mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-[#888] hover:text-[#ff1a1a] transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            На главную
          </Link>
          <p className="section-label mb-4">Обучение</p>
          <h1 className="font-display text-[clamp(32px,5vw,56px)] uppercase leading-[1] tracking-[0.02em] text-[#f5f5f5] mb-4">
            Школа детейлеров SMR
          </h1>
          <p className="text-[#888] max-w-[500px] mb-8">
            Обучение премиальному уходу за автомобилем от профессионалов индустрии.
          </p>

          {/* Price Card */}
          <div className="training-item glass-card inline-block p-8">
            <p className="text-[10px] uppercase tracking-wider text-[#555] mb-2">Стоимость курса</p>
            <p className="font-mono text-[48px] font-bold text-[#ff1a1a] leading-none">
              120 000 ₽
            </p>
            <p className="text-sm text-[#888] mt-3">
              Программа «Мастер детейлер»
            </p>
          </div>
        </div>
      </section>

      {/* Modules */}
      <section className="pb-[120px] px-6">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Modules List */}
            <div className="training-item">
              <h2 className="text-xl font-semibold text-[#f5f5f5] mb-6">
                Программа обучения
              </h2>
              <div className="space-y-3">
                {COURSE_MODULES.map((module, i) => (
                  <div
                    key={module}
                    className="flex items-center gap-4 p-4 rounded-xl bg-[#111] border border-[rgba(255,255,255,0.06)]"
                  >
                    <div className="w-8 h-8 rounded-full bg-[rgba(255,26,26,0.1)] flex items-center justify-center flex-shrink-0">
                      <span className="font-mono text-xs text-[#ff1a1a] font-bold">{i + 1}</span>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-[rgba(34,197,94,0.1)] flex items-center justify-center flex-shrink-0">
                      <Check size={14} className="text-[#22c55e]" />
                    </div>
                    <p className="text-sm text-[#f5f5f5]">{module}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="training-item">
              <div className="glass-card p-8 sticky top-[100px]">
                <h3 className="text-lg font-semibold text-[#f5f5f5] mb-4">
                  Записаться на курс
                </h3>
                <p className="text-sm text-[#888] mb-6 leading-relaxed">
                  После обучения вы получите сертификат и все необходимые знания для старта в индустрии детейлинга. Группы до 5 человек.
                </p>
                <Link
                  to="/#contacts"
                  onClick={() => {
                    setTimeout(() => {
                      document.getElementById('contacts')?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }}
                  className="btn-primary w-full"
                >
                  Записаться на курс
                  <ArrowRight size={16} />
                </Link>

                <div className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.06)] space-y-3">
                  <div className="flex items-center gap-3">
                    <Check size={14} className="text-[#22c55e] flex-shrink-0" />
                    <p className="text-xs text-[#888]">Теория + практика</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check size={14} className="text-[#22c55e] flex-shrink-0" />
                    <p className="text-xs text-[#888]">Выдача сертификата</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check size={14} className="text-[#22c55e] flex-shrink-0" />
                    <p className="text-xs text-[#888]">Поддержка после курса</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check size={14} className="text-[#22c55e] flex-shrink-0" />
                    <p className="text-xs text-[#888]">Группы до 5 человек</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
