import Hero from '@/sections/Hero';
import Advantages from '@/sections/Advantages';
import PopularServices from '@/sections/PopularServices';
import AIConfigurator from '@/sections/AIConfigurator';
import Process from '@/sections/Process';
import BeforeAfter from '@/sections/BeforeAfter';
import Cases from '@/sections/Cases';
import Reviews from '@/sections/Reviews';
import FAQ from '@/sections/FAQ';
import Contacts from '@/sections/Contacts';

export default function Home() {
  return (
    <>
      <Hero />
      <Advantages />
      <PopularServices />
      <AIConfigurator />
      <Process />
      <BeforeAfter />
      <Cases />
      <Reviews />
      <FAQ />
      <Contacts />
    </>
  );
}
