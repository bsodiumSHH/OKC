import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Clock } from 'lucide-react';
import { SERVICES } from '@/lib/constants';

export default function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const cards = section.querySelectorAll('.service-detail-card');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = '1';
            (entry.target as HTMLElement).style.transform = 'translateY(0)';
          }
        });
      },
      { threshold: 0.05 }
    );
    cards.forEach((card, i) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
      el.style.transition = `opacity 0.6s ease ${i * 0.08}s, transform 0.6s ease ${i * 0.08}s`;
      observer.observe(card);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div className="pt-[72px]" ref={sectionRef}>
      {/* Hero */}
      <section className="py-20 px-6">
        <div className="max-w-[1280px] mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-[#888] hover:text-[#ff1a1a] transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            На главную
          </Link>
          <p className="section-label mb-4">Услуги</p>
          <h1 className="font-display text-[clamp(32px,5vw,56px)] uppercase leading-[1] tracking-[0.02em] text-[#f5f5f5] mb-4">
            Услуги детейлинга
          </h1>
          <p className="text-[#888] max-w-[500px]">
            Полный перечень услуг с актуальными ценами. Все цены указаны за работу для седана класса Бизнес (×1.00).
          </p>
        </div>
      </section>

      {/* Service Grid */}
      <section className="pb-[120px] px-6">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {SERVICES.map((service) => {
              const isOnRequest = service.basePrice === 0;
              return (
                <div
                  key={service.id}
                  className="service-detail-card glass-card overflow-hidden group"
                >
                  <div className="flex flex-col sm:flex-row">
                    {/* Image */}
                    <div className="sm:w-48 h-48 sm:h-auto flex-shrink-0 overflow-hidden">
                      <img
                        src={service.image}
                        alt={service.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        loading="lazy"
                      />
                    </div>

                    {/* Content */}
                    <div className="p-6 flex-1 flex flex-col">
                      <h3 className="text-lg font-semibold text-[#f5f5f5] mb-2">
                        {service.name}
                      </h3>
                      <p className="text-sm text-[#888] mb-4 flex-1">
                        {service.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-mono text-xl font-bold text-[#ff1a1a]">
                            {isOnRequest ? 'по запросу' : `от ${service.basePrice.toLocaleString('ru-RU')} ₽`}
                          </p>
                          <p className="flex items-center gap-1 text-xs text-[#555] mt-1">
                            <Clock size={10} />
                            {service.duration}
                          </p>
                        </div>
                        <Link
                          to="/#contacts"
                          onClick={() => {
                            setTimeout(() => {
                              document.getElementById('contacts')?.scrollIntoView({ behavior: 'smooth' });
                            }, 100);
                          }}
                          className="btn-primary text-xs py-3 px-5"
                        >
                          Записаться
                          <ArrowRight size={12} />
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
