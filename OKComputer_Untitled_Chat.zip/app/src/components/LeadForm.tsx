import { useState, useCallback } from 'react';
import { IMaskInput } from 'react-imask';
import { CheckCircle, Loader2, Send } from 'lucide-react';
import { sendToTelegram } from '@/lib/telegram';
import { SERVICES } from '@/lib/constants';

interface LeadFormProps {
  prefilledService?: string;
  prefilledPrice?: string;
  prefilledCarClass?: string;
  prefilledServices?: string[];
}

export default function LeadForm({ prefilledService, prefilledPrice, prefilledCarClass, prefilledServices }: LeadFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState(prefilledService || '');
  const [comment, setComment] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = useCallback(() => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Введите имя';
    if (!phone || phone.replace(/\D/g, '').length < 11) newErrors.phone = 'Введите корректный номер';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [name, phone]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('loading');
    try {
      await sendToTelegram({
        name,
        phone,
        service: service || undefined,
        carClass: prefilledCarClass || undefined,
        services: prefilledServices || undefined,
        price: prefilledPrice || undefined,
        comment: comment || undefined,
      });
      setStatus('success');
    } catch {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="w-16 h-16 rounded-full bg-[rgba(34,197,94,0.1)] flex items-center justify-center mb-4">
          <CheckCircle size={32} className="text-[#22c55e]" />
        </div>
        <h3 className="text-xl font-semibold text-[#f5f5f5] mb-2">Заявка отправлена!</h3>
        <p className="text-sm text-[#888] max-w-sm">
          Мы свяжемся с вами в течение 15 минут для уточнения деталей.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="block text-xs uppercase tracking-wider text-[#555] mb-2">Имя</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ваше имя"
          className="w-full bg-[#111] border border-[rgba(255,255,255,0.1)] rounded-lg px-4 py-3 text-sm text-[#f5f5f5] placeholder-[#555] focus:border-[#ff1a1a] focus:outline-none transition-colors"
        />
        {errors.name && <p className="text-xs text-[#ef4444] mt-1">{errors.name}</p>}
      </div>

      <div>
        <label className="block text-xs uppercase tracking-wider text-[#555] mb-2">Телефон</label>
        <IMaskInput
          mask="+{7} (000) 000-00-00"
          value={phone}
          onAccept={(val: string) => setPhone(val)}
          placeholder="+7 (___) ___-__-__"
          className="w-full bg-[#111] border border-[rgba(255,255,255,0.1)] rounded-lg px-4 py-3 text-sm text-[#f5f5f5] placeholder-[#555] focus:border-[#ff1a1a] focus:outline-none transition-colors font-mono"
        />
        {errors.phone && <p className="text-xs text-[#ef4444] mt-1">{errors.phone}</p>}
      </div>

      <div>
        <label className="block text-xs uppercase tracking-wider text-[#555] mb-2">Услуга</label>
        <select
          value={service}
          onChange={(e) => setService(e.target.value)}
          className="w-full bg-[#111] border border-[rgba(255,255,255,0.1)] rounded-lg px-4 py-3 text-sm text-[#f5f5f5] focus:border-[#ff1a1a] focus:outline-none transition-colors appearance-none cursor-pointer"
        >
          <option value="">Выберите услугу</option>
          {SERVICES.map((s) => (
            <option key={s.id} value={s.name}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-xs uppercase tracking-wider text-[#555] mb-2">Комментарий</label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Марка и модель автомобиля, пожелания..."
          rows={3}
          className="w-full bg-[#111] border border-[rgba(255,255,255,0.1)] rounded-lg px-4 py-3 text-sm text-[#f5f5f5] placeholder-[#555] focus:border-[#ff1a1a] focus:outline-none transition-colors resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={status === 'loading'}
        className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {status === 'loading' ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            Отправка...
          </>
        ) : (
          <>
            <Send size={16} />
            Отправить заявку
          </>
        )}
      </button>

      {status === 'error' && (
        <p className="text-xs text-[#ef4444] text-center">
          Ошибка отправки. Попробуйте позже или позвоните нам.
        </p>
      )}

      <p className="text-[11px] text-[#555] text-center">
        Нажимая кнопку, вы соглашаетесь с обработкой персональных данных
      </p>
    </form>
  );
}
