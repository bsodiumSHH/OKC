import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { COMPANY } from '@/lib/constants';

const NAV_LINKS = [
  { label: 'Услуги', href: '/services' },
  { label: 'Галерея', href: '/gallery' },
  { label: 'AI-Расчёт', href: '/#ai-configurator' },
  { label: 'Отзывы', href: '/#reviews' },
  { label: 'Контакты', href: '/#contacts' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const isHome = location.pathname === '/';

  const scrollToSection = (href: string) => {
    if (!isHome && href.startsWith('/#')) {
      return;
    }
    if (href.startsWith('/#')) {
      const id = href.replace('/#', '');
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
        setMobileOpen(false);
      }
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 h-[72px] flex items-center transition-all duration-500 ${
          scrolled
            ? 'bg-[rgba(5,5,5,0.9)] backdrop-blur-xl border-b border-[rgba(255,255,255,0.06)]'
            : 'bg-transparent'
        }`}
      >
        <div className="w-full max-w-[1280px] mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            className="font-display text-[20px] font-bold tracking-[0.2em] text-[#f5f5f5] hover:text-[#ff1a1a] transition-colors"
          >
            SMR
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) =>
              link.href.startsWith('/#') ? (
                <button
                  key={link.href}
                  onClick={() => scrollToSection(link.href)}
                  className="relative text-sm text-[#888] hover:text-[#f5f5f5] transition-colors group"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#ff1a1a] transition-all duration-300 group-hover:w-full" />
                </button>
              ) : (
                <Link
                  key={link.href}
                  to={link.href}
                  className="relative text-sm text-[#888] hover:text-[#f5f5f5] transition-colors group"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#ff1a1a] transition-all duration-300 group-hover:w-full" />
                </Link>
              )
            )}
          </nav>

          {/* CTA + Mobile Toggle */}
          <div className="flex items-center gap-4">
            <a
              href={`tel:${COMPANY.phoneRaw}`}
              className="hidden md:inline-flex items-center gap-2 text-sm text-[#888] hover:text-[#ff1a1a] transition-colors"
            >
              <Phone size={14} />
              {COMPANY.phone}
            </a>
            <Link
              to="/#contacts"
              onClick={() => scrollToSection('/#contacts')}
              className="hidden md:inline-flex btn-primary text-xs py-3 px-6"
            >
              Записаться
            </Link>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 text-[#f5f5f5]"
              aria-label="Menu"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-[#050505] transition-all duration-500 lg:hidden ${
          mobileOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8 pt-[72px]">
          {NAV_LINKS.map((link, i) =>
            link.href.startsWith('/#') ? (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className="font-display text-2xl uppercase tracking-[0.1em] text-[#f5f5f5] hover:text-[#ff1a1a] transition-colors"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                {link.label}
              </button>
            ) : (
              <Link
                key={link.href}
                to={link.href}
                className="font-display text-2xl uppercase tracking-[0.1em] text-[#f5f5f5] hover:text-[#ff1a1a] transition-colors"
              >
                {link.label}
              </Link>
            )
          )}
          <a
            href={`tel:${COMPANY.phoneRaw}`}
            className="mt-4 inline-flex items-center gap-2 text-[#ff1a1a]"
          >
            <Phone size={18} />
            <span className="font-mono">{COMPANY.phone}</span>
          </a>
        </div>
      </div>
    </>
  );
}
