import { Link } from 'react-router-dom';
import { ArrowUp, Phone, MapPin, Clock } from 'lucide-react';
import { COMPANY } from '@/lib/constants';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#000] pt-20 pb-10 px-6">
      <div className="max-w-[1280px] mx-auto">
        {/* Top */}
        <div className="flex flex-col lg:flex-row justify-between gap-12 mb-16">
          {/* Logo + Info */}
          <div>
            <Link to="/" className="font-display text-2xl font-bold tracking-[0.2em] text-[#f5f5f5]">
              SMR
            </Link>
            <p className="text-sm text-[#555] mt-2 uppercase tracking-wider">Детейлинг-премиум</p>
            <div className="mt-6 space-y-3">
              <div className="flex items-center gap-3 text-sm text-[#888]">
                <MapPin size={14} className="text-[#ff1a1a]" />
                {COMPANY.address}
              </div>
              <div className="flex items-center gap-3 text-sm text-[#888]">
                <Phone size={14} className="text-[#ff1a1a]" />
                {COMPANY.phone}
              </div>
              <div className="flex items-center gap-3 text-sm text-[#888]">
                <Clock size={14} className="text-[#ff1a1a]" />
                {COMPANY.hours}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="text-xs uppercase tracking-[0.15em] text-[#555] mb-4">Навигация</h4>
              <nav className="space-y-3">
                <Link to="/services" className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">Услуги</Link>
                <Link to="/gallery" className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">Галерея</Link>
                <Link to="/training" className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">Обучение</Link>
              </nav>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-[0.15em] text-[#555] mb-4">Контакты</h4>
              <nav className="space-y-3">
                <a href={`tel:${COMPANY.phoneRaw}`} className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">Позвонить</a>
                <a href={COMPANY.whatsapp} target="_blank" rel="noopener noreferrer" className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">WhatsApp</a>
                <a href={COMPANY.telegram} target="_blank" rel="noopener noreferrer" className="block text-sm text-[#888] hover:text-[#ff1a1a] transition-colors">Telegram</a>
              </nav>
            </div>
          </div>
        </div>

        {/* Decorative Text */}
        <div className="relative overflow-hidden py-8 border-t border-[rgba(255,255,255,0.05)]">
          <p className="font-display text-[clamp(36px,8vw,100px)] uppercase leading-none tracking-[0.05em] text-center" style={{ color: 'rgba(255,255,255,0.03)' }}>
            SMR Auto. Detailing
          </p>
        </div>

        {/* Bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-[rgba(255,255,255,0.05)]">
          <p className="text-xs text-[#555]">
            © 2025 {COMPANY.name}. Все права защищены.
          </p>
          <div className="flex items-center gap-6">
            <a href={COMPANY.yandexMap} target="_blank" rel="noopener noreferrer" className="text-xs text-[#555] hover:text-[#ff1a1a] transition-colors">
              Яндекс.Карты
            </a>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-2 text-xs text-[#555] hover:text-[#ff1a1a] transition-colors group"
            >
              Наверх
              <ArrowUp size={12} className="group-hover:-translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
