# SMR Detailing — Техническая спецификация

## Стек
- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Animations**: GSAP + ScrollTrigger + Lenis
- **3D**: Three.js + @react-three/fiber + @react-three/drei
- **Routing**: React Router DOM (HashRouter для статического деплоя)
- **Utilities**: react-countup, react-imask, lucide-react

## Архитектура

### Структура проекта
```
src/
├── pages/
│   ├── Home.tsx              # Главная страница
│   ├── Services.tsx          # Страница услуг
│   ├── Gallery.tsx           # Галерея
│   └── Training.tsx          # Обучение
├── sections/
│   ├── Hero.tsx              # Hero секция
│   ├── Advantages.tsx        # Преимущества
│   ├── PopularServices.tsx   # Популярные услуги
│   ├── AIConfigurator.tsx    # AI-конфигуратор
│   ├── Process.tsx           # Процесс работы
│   ├── BeforeAfter.tsx       # До/после
│   ├── Cases.tsx             # Кейсы
│   ├── Reviews.tsx           # Отзывы
│   ├── FAQ.tsx               # FAQ
│   └── Contacts.tsx          # Контакты + форма
├── components/
│   ├── Header.tsx            # Шапка
│   ├── Footer.tsx            # Подвал
│   ├── LeadForm.tsx          # Форма захвата
│   ├── PriceTag.tsx          # Компонент цены
│   ├── ScrollReveal.tsx      # Анимация появления
│   ├── HeroCanvas.tsx        # Three.js сцена
│   ├── BeforeAfterSlider.tsx # Слайдер до/после
│   ├── ServiceGlassWipe.tsx  # Стеклянная шторка
│   └── MobileMenu.tsx        # Мобильное меню
├── hooks/
│   ├── useLenis.ts           # Хук Lenis smooth scroll
│   ├── useScrollReveal.ts    # Хук ScrollReveal
│   └── useTelegram.ts        # Хук отправки в Telegram
├── lib/
│   ├── utils.ts              # Утилиты shadcn
│   ├── telegram.ts           # sendToTelegram()
│   └── constants.ts          # Константы (цены, данные)
└── types/
    └── index.ts              # TypeScript типы
```

### State Management
- Локальный state (useState) — для форм, UI
- React Context — для данных компании (контакты, цены)
- URL params — для навигации по страницам

### Routing
```
/                    → Home
/#/services          → Services
/#/gallery           → Gallery
/#/training          → Training
```

## Компоненты

### shadcn/ui (устанавливаются через CLI)
- `accordion` — FAQ секция
- `button` — CTA кнопки
- `input` — поля форм
- `textarea` — комментарий
- `select` — выбор услуги
- `card` — карточки услуг
- `badge` — метки/статусы
- `separator` — разделители

### Кастомные компоненты
| Компонент | Описание | Сложность |
|---|---|---|
| HeroCanvas | Three.js chrome-сфера + частицы | High |
| AIConfigurator | 4-шаговый интерактивный конфигуратор | High |
| ServiceGlassWipe | Scroll-driven glass wipe эффект | High |
| BeforeAfterSlider | Draggable до/после | Medium |
| ScrollReveal | GSAP ScrollTrigger reveal wrapper | Low |
| LeadForm | Валидация + Telegram отправка | Medium |
| Header | Sticky + blur + mobile menu | Medium |

## Анимации

| Анимация | Библиотека | Реализация | Сложность |
|---|---|---|---|
| Hero Canvas (3D сфера) | Three.js + R3F | IcosahedronGeometry + MeshPhysicalMaterial + RoomEnvironment | High |
| Scroll Reveal (все секции) | GSAP ScrollTrigger | batch() с opacity/y stagger | Low |
| AI Configurator transitions | GSAP | Timeline между шагами | Medium |
| Laser Scan Effect | CSS + GSAP | Анимированная красная линия + статусы | Medium |
| Price Counter | react-countup | Анимированный подсчёт суммы | Low |
| Service Glass Wipe | GSAP ScrollTrigger scrub | clip-path анимация + sticky | High |
| Before/After Slider | React + CSS | onMouseDrag + clip-path | Medium |
| Button Hover Effects | CSS | clip-path fill снизу | Low |
| Nav Underline | CSS | scaleX transform | Low |
| Mobile Menu | GSAP | Slide-in overlay | Low |
| Process Timeline | GSAP ScrollTrigger | Прогресс-линия заполняется | Medium |

## Утилиты

### telegram.ts
```typescript
const BOT_TOKEN = '8087011039:AAHk4YVzrwBFn-kaao0IarEB2VjrpICBzBw';
const CHAT_ID = '8087011039';

interface TelegramData {
  name: string;
  phone: string;
  carClass?: string;
  services?: string[];
  price?: string;
  comment?: string;
}

export async function sendToTelegram(data: TelegramData): Promise<void>
```

### constants.ts
```typescript
export const COMPANY = {
  name: 'SMR Detailing',
  address: 'Волгоград, Череповецкая ул., 98',
  phone: '+7 (937) 088-07-88',
  hours: 'Ежедневно с 10:00 до 20:00',
  rating: 5.0,
  reviews: 55,
  scores: 81,
};

export const CAR_CLASSES = [
  { id: 'sedan', name: 'Седан / Бизнес', factor: 1.0 },
  { id: 'crossover', name: 'Кроссовер', factor: 1.25 },
  { id: 'suv', name: 'Внедорожник / Спорткар', factor: 1.45 },
];

export const SERVICES = [
  { id: 'wash', name: 'Детейлинг-мойка', basePrice: 7000 },
  { id: 'polish', name: 'Восстановительная полировка', basePrice: 35000 },
  { id: 'interior', name: 'Химчистка салона', basePrice: 16000 },
  { id: 'ceramic', name: 'Керамическое покрытие', basePrice: 30000 },
  { id: 'ppf', name: 'Антигравийная плёнка', basePrice: 45000 },
  { id: 'engine', name: 'Мойка двигателя', basePrice: 6000 },
  { id: 'tint', name: 'Тонировка', basePrice: 3000 },
  { id: 'wrap', name: 'Оклейка элементов', basePrice: 2000 },
  { id: 'dent', name: 'Удаление вмятин', basePrice: 2000 },
  { id: 'fog', name: 'Сухой туман', basePrice: 0 }, // по запросу
  { id: 'complex', name: 'Комплексный пакет', basePrice: 85000 },
];
```

## Зависимости

```json
{
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-router-dom": "^7.0.0",
    "three": "^0.170.0",
    "@react-three/fiber": "^9.0.0",
    "@react-three/drei": "^9.0.0",
    "gsap": "^3.12.0",
    "@gsap/react": "^2.1.0",
    "lenis": "^1.1.0",
    "react-countup": "^6.5.0",
    "react-imask": "^7.6.0",
    "lucide-react": "^0.460.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.6.0"
  },
  "devDependencies": {
    "@types/three": "^0.170.0"
  }
}
```

## План разработки

### Этап 1: Инфраструктура
1. Инициализация проекта через `init-webapp.sh`
2. Установка дополнительных зависимостей (three, gsap, lenis, react-countup, react-imask, react-router-dom)
3. Настройка шрифтов (Google Fonts: Syncopate, Inter, Oxygen Mono)
4. Настройка Tailwind темы (цвета, типографика)
5. Создание constants.ts с данными

### Этап 2: Layout
1. Header (sticky + blur + mobile menu)
2. Footer
3. Lenis smooth scroll setup
4. React Router routing

### Этап 3: Home Page Sections
1. Hero (HeroCanvas + текст)
2. Advantages
3. PopularServices
4. AIConfigurator
5. Process
6. BeforeAfter
7. Cases
8. Reviews
9. FAQ
10. Contacts

### Этап 4: Inner Pages
1. Services page
2. Gallery page
3. Training page

### Этап 5: Polish
1. GSAP ScrollTrigger анимации
2. Three.js оптимизация
3. Responsive (mobile/tablet)
4. Performance (lazy loading, code splitting)
5. Accessibility

### Этап 6: Deploy
1. Build
2. Deploy via deploy_website

## Performance Considerations
- HeroCanvas: отключать на mobile, заменять на CSS градиент
- AIConfigurator: lazy load (React.lazy + Suspense)
- Images: WebP формат, lazy loading, blur placeholder
- Three.js: оптимизировать геометрию, использовать RoomEnvironment
- GSAP: использовать batch() для групповых анимаций
- Code splitting по страницам

## Responsive Breakpoints
- Desktop: > 1024px — полная раскладка
- Tablet: 768-1024px — 2 колонки
- Mobile: < 768px — 1 колонка, упрощённые анимации
